using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class NearbyAlliesTileEvaluator : TileEvaluator
{
    private float _bestScore = 0f;
    private Dictionary<OverlayTile, float> _scores;

    public override void PreEvaluate(HashSet<OverlayTile> availableDestinations, Unit evaluatingUnit, TileGrid tileGrid, Dictionary<Unit, List<Tuple<OverlayTile, float>>> encounterScores)
    {
        _scores = new Dictionary<OverlayTile, float>();

        foreach (var tile in availableDestinations)
        {
            var nearbyAllies = 0;
            foreach (var ally in tileGrid.GetCurrentPlayerUnits())
            {
                if(ally.GetTilesInRange(tileGrid, 3).Contains(tile))
                    nearbyAllies += 1;
            }
            _scores[tile] = nearbyAllies;

            // maximum best score should be 2, an abritrary number. Anything more than 2 would make enemies clump together
            if (nearbyAllies > 2)
            {
                _bestScore = nearbyAllies;
                break;
            }
            else if(nearbyAllies > _bestScore)
            {
                _bestScore = nearbyAllies;
            }

        }
    }

    public override float Evaluate(OverlayTile tileToEvaluate, Unit evaluatingUnit, TileGrid tileGrid)
    {
        if (!_scores.ContainsKey(tileToEvaluate))
            return 0f;

        return _scores[tileToEvaluate]/_bestScore * .5f; // I dont want this evaluator to be too heavily weighted
    }    
}
