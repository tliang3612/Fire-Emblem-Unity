using System.Collections;
using System.Collections.Generic;

public interface IClickable
{
    void OnPointerDown();
}
