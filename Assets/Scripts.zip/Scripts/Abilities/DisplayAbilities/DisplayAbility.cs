using System;
using UnityEngine;
using System.Linq;
using System.Collections;
using System.Collections.Generic;

//change to displayStats Ability
public class DisplayAbility : Ability
{
    public override void OnAbilitySelected(TileGrid tileGrid)
    {
        base.OnAbilitySelected(tileGrid);
    }

    public override void OnAbilityDeselected(TileGrid tileGrid)
    {
        base.OnAbilityDeselected(tileGrid);
    }
}
